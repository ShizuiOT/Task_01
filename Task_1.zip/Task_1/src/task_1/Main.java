package task_1;
public class Main {
    public static void main(String[] args) {
        Vozv voz = new Vozv();
        voz.summ();
    }
}
